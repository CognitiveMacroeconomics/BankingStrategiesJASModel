package de.jungblut.classification.nn;

/**
 * Train normally on the CPU or on the GPU via CUDA?
 */
public enum TrainingType {
  CPU, GPU
}
